package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Employee {
	private int eid;
	private String ename;
	private int esal;
	@Autowired
	private Address address;
	
	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getEsal() {
		return esal;
	}

	public void setEsal(int esal) {
		this.esal = esal;
	}

	public Address getAddress() {
		return address;
	}
@Autowired
	public void setAddress(Address address) {
		this.address = address;
	}

	public void display() {
		address.setHno(12);
		address.setCity("hyd");
		System.out.println("employee class");
		System.out.println(eid+" "+ename+" "+esal+" "+address.getHno()+"  "+address.getCity());
		
		
	}
	
	

}
