package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		
	/*	Resource resource=  new ClassPathResource("applicationContext.xml");
		BeanFactory factory= new XmlBeanFactory(resource);*/
		ApplicationContext factory=new AnnotationConfigApplicationContext(AppConfig.class);
		Object obj= factory.getBean("emp");
		Employee e= (Employee)obj;
		e.display();	
		
	}
}
