
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		
	/*	Resource resource=  new ClassPathResource("applicationContext.xml");
		BeanFactory factory= new XmlBeanFactory(resource);*/
		ApplicationContext factory=new ClassPathXmlApplicationContext("applicationContext.xml");
		Object obj= factory.getBean("emp");
		Employee e= (Employee)obj;
		e.display();	
		Object obj1= factory.getBean("emp");
		Employee e1= (Employee)obj1;
		System.out.println(e+"\n"+e1);
	}
}
