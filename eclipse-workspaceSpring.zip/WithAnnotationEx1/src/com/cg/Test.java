package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		
	/*	Resource resource=  new ClassPathResource("applicationContext.xml");
		BeanFactory factory= new XmlBeanFactory(resource);*/
		ApplicationContext factory=new ClassPathXmlApplicationContext("applicationContext.xml");
		Object obj= factory.getBean("emp");
		Employee e= (Employee)obj;
		e.setName("Richika");
		e.setSalary(2000);
		e.getAdd().setCity("kolkata");
		e.getAdd().setHno(90);
		e.getAdd().setState("West bengal");
		e.display();	
		
	}
}
