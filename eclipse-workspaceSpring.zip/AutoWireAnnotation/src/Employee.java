import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
private String name;
private  int salary;
@Autowired	//for the property, its byType by default...<property>
private Address add;
//@Autowired
public Employee(String name, int salary, Address add) {
	super();
	this.name = name;
	this.salary = salary;
	this.add = add;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
public Address getAdd() {
	return add;
}
//@Autowired
public void setAdd(Address add) {
	this.add = add;
}

public void display() {
	System.out.println("Name:"+name+"\nSalary:"+salary+"\nAddress:"+add);
}
public Employee() {}

}
