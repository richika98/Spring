import java.util.List;

public class Employee {
private String name;
private  int salary;
private List<Address> add;

public void display() {
	System.out.println("Name:"+name+"\nSalary:"+salary+"\nAddress:"+add);
}
public Employee() {}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
public List<Address> getAdd() {
	return add;
}
public void setAdd(List<Address> add) {
	this.add = add;
}
public Employee(String name, int salary, List<Address> add) {
	super();
	this.name = name;
	this.salary = salary;
	this.add = add;
}



}
