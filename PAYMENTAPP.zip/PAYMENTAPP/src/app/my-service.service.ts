import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { concat } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
http:HttpClient;
account:Account[]=[];
accountFetched:boolean=false;

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchAccount();
  }

fetchAccount(){
  this.http.get('./assets/Account.json').subscribe(
  data=>{
    if(!this.accountFetched){
      this.convert(data);
      this.accountFetched=true;
    }
  }
);
}

convert(data:any){
  for(let o of data){
    let p = new Account(o.name,o.contact,o.address,o.balance,o.accountNumber);
    this.account.push(p);
  }
    }

    getAccount():Account[]{
      return this.account;
    }

    create(acc:Account){
      
      let aNum:string;
      aNum=acc.name.substr(0,4).toUpperCase();
      aNum+=acc.contact.toString();
      acc.accountNumber=aNum;
      this.account.push(acc);
      console.log(this.account.length);
      window.alert("Your account number:"+acc.accountNumber);
    }



}


export class Account{
  name:string;
  contact:number;
  address:string;
  balance:number;
  accountNumber:string;
  constructor(name:string, contact:number,address:string,balance:number,accountNumber:string){
    this.name=name;
    this.contact=contact;
    this.address=address;
    this.balance=balance;
    this.accountNumber=accountNumber;
  }
}