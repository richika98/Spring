import { Component, OnInit } from '@angular/core';
import { MyServiceService, Account } from '../my-service.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
service:MyServiceService;
account:Account;

  constructor(service:MyServiceService) { 
    this.service=service;
  }

  create(data:any){
    this.account= new Account(data.name,data.contact,data.address,data.balance,"");
    this.service.create(this.account);
  }

  ngOnInit() {
  }

}
