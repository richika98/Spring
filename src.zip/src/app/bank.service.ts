import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';



export class Bank {
    accountNo: number;
    firstName: string;
    lastName:string;
    mobileNo:number;
    address:string;
    accBal: number;
     
   

    constructor(firstName:string, lastName:string,mobileNo:number,address:string,accBal:number) {
      this.firstName=firstName;
      this.lastName=lastName;
      this.mobileNo=mobileNo;
      this.address=address;
      this.accBal=accBal;
        
    }
}

export class History {
    tid:number;
    type:string;
    amountTransferred:number;
    accountNo:number;

    constructor( tid:number,type:string, amountTransferred:number,accountNo:number) {
       this.tid=tid;
       this.type=type;
       this.amountTransferred=amountTransferred;
       this.accountNo=accountNo;

    }

} 


@Injectable({
  providedIn: 'root'
})


export class BankService {

  constructor(private http:HttpClient) { }
bank:Bank;
  public createAccount(bank){
      const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.post("http://localhost:1234/add/account",bank,  { headers, responseType: 'text'});
  }

  public showBalance(acc_id){
      const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
      return this.http.get("http://localhost:1234/account/balance"+"/"+acc_id,  { headers, responseType: 'text'});

  }

   public deposit(acc_id,amount){
        const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
      return this.http.get("http://localhost:1234/account/deposit"+"/"+acc_id+"/"+amount,  { headers, responseType: 'text'});
  }

   public withdraw(acc_id,amount){
        const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
      return this.http.get("http://localhost:1234/account/withdraw"+"/"+acc_id+"/"+amount,  { headers, responseType: 'text'});
  }

   public fundtransfer(acc_id,acc_id2,amount){
        const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
      return this.http.get("http://localhost:1234/account/transfer"+"/"+acc_id+"/"+acc_id2+"/"+amount,  { headers, responseType: 'text'});
  }
  
  
  public history(acc_id){
       const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
      return this.http.get<History[]>("http://localhost:1234/bank/transactions/"+acc_id);


  }

}
