import { Component, OnInit } from '@angular/core';
import { Bank } from 'src/app/Entity/Bank';
import { Transaction } from 'src/app/Entity/Transaction';
import { Router } from '@angular/router';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  createdCustomers: Bank[] = [];
  createdTransaction: Transaction;
  createdFlag: boolean = false;
  router: Router;
  service: BankService;


  constructor(service: BankService, router: Router) {
    this.service = service;
    this.router = router;
  }

  a:Bank;

  add(data: any) {
    data.bal = 3000;
    let bank = this.service.add(data.pwd, data.name, data.mobNo, data.address, data.bal);
    bank.subscribe(
      (dataa) => {
        //console.log(dataa)
        this.a = dataa;
        console.log(this.a.accNo)
        alert("Welcome!!!\nYour Account No. is : " + this.a.accNo)
        this.service.customers.push(this.a)
       
      }

    );

    this.createdFlag = true;
    this.router.navigate(['app-login']);
  }

  ngOnInit() {
  }

}
