import { Component, OnInit } from '@angular/core';
import { BankService } from 'src/app/Service/bank.service';
import { Router } from '@angular/router';
import { Bank } from 'src/app/Entity/Bank';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  service:BankService;
  router:Router;

  message:string;
  newMessage() {
    this.service.changeMessage("login")
  }

  constructor(service:BankService,router:Router) { 
    this.service=service;
    this.router=router;
  }

  customers:Bank[]=[];
  isLogin:boolean=true;

  login(data:any){
    
    if(this.service.login(data)){
      
      this.isLogin=this.service.isLogin;
      this.router.navigate(['app-home']);
    }else{
      alert("Values does not matched!")
    }
  }

  ngOnInit() {
  
    this.service.currentMessage.subscribe(message => this.message = message)
  }
}
