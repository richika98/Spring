import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './Starter/register/register.component';
import { LoginComponent } from './Starter/login/login.component';
import { DepositComponent } from './Operations/deposit/deposit.component';
import { WithdrawComponent } from './Operations/withdraw/withdraw.component';
import { ShowBalanceComponent } from './Operations/show-balance/show-balance.component';
import { AccountDetailsComponent } from './Operations/account-details/account-details.component';
import { FundTransferComponent } from './Operations/fund-transfer/fund-transfer.component';
import { PrintStatementComponent } from './Operations/print-statement/print-statement.component';
import { BankService } from './Service/bank.service';
import { HomeComponent } from './Starter/home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    DepositComponent,
    WithdrawComponent,
    ShowBalanceComponent,
    AccountDetailsComponent,
    FundTransferComponent,
    PrintStatementComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [HttpClient,BankService],
  bootstrap: [AppComponent]
})
export class AppModule { }
