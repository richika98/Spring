import { Component, OnInit } from '@angular/core';
import { Bank } from 'src/app/Entity/Bank';
import { Transaction } from 'src/app/Entity/Transaction';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  isLogin:boolean=true;
  customers:Bank[]=[];
  createdTransaction:Transaction;
  bal:number;
  accNo:number;
  
  service:BankService;
  constructor(service:BankService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  withdrawAmount(data:any){

    this.accNo = this.service.loginAccount;
    this.bal = data.bal;
    var withdraw = this.service.withdrawBalance(this.accNo, this.bal);
    withdraw.subscribe( (data) =>{
      alert("Amount Withdrawn From Your Account");
    }
    )
  }
  ngOnInit() {
  }

}
