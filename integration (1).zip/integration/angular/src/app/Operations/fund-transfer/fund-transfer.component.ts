import { Component, OnInit } from '@angular/core';
import { BankService } from 'src/app/Service/bank.service';
import { Transaction } from 'src/app/Entity/Transaction';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  isLogin: boolean = true;
  createdTransaction: Transaction;
  service: BankService;
  accNo:number;
  accNo2: number;
  bal: number;


  constructor(service: BankService) {
    this.service = service;
    this.isLogin = this.service.isLogin;
  }

  fundTransfer(data: any) {
    this.bal = data.bal;
    this.accNo = this.service.loginAccount;
    this.accNo2 = data.accNo2;

    var transfer = this.service.fundTransfer(this.accNo,this.bal,this.accNo2)
    transfer.subscribe( (data) => {
      alert("FundTransfered");
    })

  }

  ngOnInit() {
  }

}
