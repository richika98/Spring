import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintStatementComponent } from './print-statement.component';

describe('PrintStatementComponent', () => {
  let component: PrintStatementComponent;
  let fixture: ComponentFixture<PrintStatementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrintStatementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
