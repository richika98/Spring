import { Component, OnInit } from '@angular/core';
import { Transaction } from 'src/app/Entity/Transaction';
import { Bank } from 'src/app/Entity/Bank';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'app-print-statement',
  templateUrl: './print-statement.component.html',
  styleUrls: ['./print-statement.component.css']
})
export class PrintStatementComponent implements OnInit {

  transactions:Transaction[]=[];
  customers:Bank[]=[];
  service:BankService;


  constructor(service:BankService) { 
    this.service=service;
  }

  miniStatement(){
    let mini = this.service.miniStatement(this.service.loginAccount);
    mini.subscribe( (data) => {
      this.transactions = data;
      console.log(this.transactions)
    })
  }

  ngOnInit() {
    this.miniStatement();
  }

}
