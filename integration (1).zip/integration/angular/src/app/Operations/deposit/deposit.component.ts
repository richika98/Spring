import { Component, OnInit } from '@angular/core';
import { Bank } from 'src/app/Entity/Bank';
import { Transaction } from 'src/app/Entity/Transaction';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  isLogin: boolean = true;
  customers: Bank[] = [];
  createdTransaction: Transaction;
  bal: number;
  accNo1: number;
  service: BankService;
  constructor(service: BankService) {
    this.service = service;
    this.isLogin = this.service.isLogin;
  }

  depositeAmount(data: any) {

    this.accNo1 = this.service.loginAccount;
    this.bal = data.bal;
    var deposit = this.service.depositeBalance(this.accNo1, this.bal);

    deposit.subscribe((data) => {
      this.bal = data;
      alert("Amount Deposited in Your Account");
    }
    )
  }

  ngOnInit() {
  }


}
