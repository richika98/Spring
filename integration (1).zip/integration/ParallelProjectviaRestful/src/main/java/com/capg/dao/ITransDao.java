package com.capg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capg.entity.Transaction;
@Repository
public interface ITransDao extends JpaRepository<Transaction, Long> {
	@Query("from Transaction where accno=?1")
	List<Transaction> printTransaction(Long accNo);
}
