package com.capg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.entity.Bank;
import com.capg.entity.Transaction;
import com.capg.exception.AccountNotFoundException;
import com.capg.service.IBankService;


@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/bank")
public class BankRestFulController {
	@Autowired
	IBankService service;

	@PostMapping("/createAccount")
	@CrossOrigin(origins="http://localhost:4200")
	public Optional<Bank> createAccount(@RequestBody Bank bean) {
		return service.createAccount(bean);
	}

	@GetMapping("/accountDetails/{accNo}")
	@CrossOrigin(origins="http://localhost:4200")
	public Bank accountDetails(@PathVariable Long accNo) throws AccountNotFoundException {
		return service.accountDetails(accNo);
	}

	@GetMapping("/showBalance/{accNo}")
	@CrossOrigin(origins="http://localhost:4200")
	public Double showBalance(@PathVariable Long accNo) throws AccountNotFoundException {
		return  service.showBalance(accNo);
		
	}

	@PutMapping("/depositBalance/{accNo}/{amt}")
	public Double deposit(@PathVariable Long accNo, @PathVariable Double amt) throws AccountNotFoundException {
		return service.depositBalance(accNo, amt);
		
	}

	@PutMapping("/withdrawBalance/{accNo}/{amt}")
	public Double withdraw(@PathVariable Long accNo, @PathVariable Double amt) throws AccountNotFoundException {
		return service.withdrawBalance(accNo, amt);
		
	}

	@PutMapping("/fundTransfer/{accNo1}/{amt}/{accNo2}")
	public Double fundTransfer(@PathVariable Long accNo1, @PathVariable Double amt,
			@PathVariable Long accNo2) throws AccountNotFoundException {
		return  service.fundTransfer(accNo1, amt, accNo2);
		
	}

	@GetMapping("/printTransaction/{accNo}")
	@CrossOrigin(origins="http://localhost:4200")
	public List<Transaction> printTransaction(@PathVariable Long accNo) throws AccountNotFoundException {
		System.out.println("A");
		return service.printTransaction(accNo);
	}
	 @GetMapping("/showAll")
	    @CrossOrigin(origins="https://localhost:4200")
	    public List<Bank> showAll() {
	        return service.showAll();
	    }
	@ExceptionHandler(AccountNotFoundException.class)
    public ResponseEntity<String> accountNotFound(AccountNotFoundException e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

}
