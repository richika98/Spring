package com.cg.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entities.Account;
import com.cg.repository.BankRepository;

@Service("service")
public class BankServiceImpl implements BankService{
	
	@Autowired
	BankRepository dao;

	public Account createAccount(Account account) {
		char []ch=account.getCustName().toCharArray();
		String accountNum="";
		for(int i=0;i<4;i++) {
			ch[i]=Character.toUpperCase(ch[i]);
			accountNum=accountNum+ch[i];				//generating account number
		}
		accountNum=accountNum+account.getMobileNumber();
		account.setAccountNumber(accountNum);
	 dao.save(account);
		return account;
	}

	public long showBalance(String accountNumber) {
		if(dao.existsById(accountNumber)) {
			Optional<Account> a =dao.findById(accountNumber);
					
				 Account acc=a.get();
				 return acc.getBalance();
			}
		
		return -1;
	}

	public long deposit(String accountNumber,Long balance) {
		if(dao.existsById(accountNumber)) {
			Optional<Account> a =dao.findById(accountNumber);
					
				 Account acc=a.get();
				 //System.out.println(acc.getBalance());
				long newBalance=acc.getBalance()+balance;
				acc.setBalance(newBalance);
				 dao.save(acc);
				 return newBalance;
			}
		else
			
		return -1;
	}
	
	public long withdraw(String accountNumber,Long balance) {
		if(dao.existsById(accountNumber)) {
			Optional<Account> a =dao.findById(accountNumber);
					
				 Account acc=a.get();
				// System.out.println(acc.getBalance());
				 if(acc.getBalance()>balance) {
				long newBalance=acc.getBalance()-balance;
				acc.setBalance(newBalance);
				 dao.save(acc);
				 return newBalance;
				 }
				 return -1;
			}
		else
			
		return -1;
	}

	@Override
	public List<Account> transfer(@Valid String sAccountNumber, String rAccountNumber, Long balance) {
		if(dao.existsById(sAccountNumber) && dao.existsById(sAccountNumber)) {
			Optional<Account> s =dao.findById(sAccountNumber);
			Optional<Account> r =dao.findById(rAccountNumber);
			 Account sAcc=s.get();
			 Account rAcc=r.get();
			 if(sAcc.getBalance()>balance) {
				 long sBalance=sAcc.getBalance()-balance;
				 long rBalance=rAcc.getBalance()+balance;
				 sAcc.setBalance(sBalance);
				 rAcc.setBalance(rBalance);
				 dao.save(sAcc);
				 dao.save(rAcc);
				 return dao.findAll();
			 }
		}
		return null;
	}

}
