package com.cg.service;

import java.util.List;

import javax.validation.Valid;

import com.cg.entities.Account;

public interface BankService {
	Account createAccount(Account account);
	long showBalance(String accountNumber);
	long deposit(String accountNumber,Long balance);
	long withdraw(String accountNumber,Long balance);
	List<Account> transfer(@Valid String sAccountNumber, String rAccountNumber, Long balance);
}
