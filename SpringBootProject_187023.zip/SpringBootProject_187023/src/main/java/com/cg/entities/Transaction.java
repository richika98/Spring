package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Transaction {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int transid;
	long transAmount;
	private String type;
	private String transTo,transFrom;
	public int getTransid() {
		return transid;
	}
	public void setTransid(int transid) {
		this.transid = transid;
	}
	public long getTransAmount() {
		return transAmount;
	}
	public void setTransAmount(long transAmount) {
		this.transAmount = transAmount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTransTo() {
		return transTo;
	}
	public void setTransTo(String transTo) {
		this.transTo = transTo;
	}
	public String getTransFrom() {
		return transFrom;
	}
	public void setTransFrom(String transFrom) {
		this.transFrom = transFrom;
	}
	public Transaction(int transid, long transAmount, String type, String transTo, String transFrom) {
		super();
		this.transid = transid;
		this.transAmount = transAmount;
		this.type = type;
		this.transTo = transTo;
		this.transFrom = transFrom;
	}
	
	public Transaction() {
	}
	
}
