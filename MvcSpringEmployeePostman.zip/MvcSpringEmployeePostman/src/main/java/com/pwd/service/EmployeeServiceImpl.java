package com.pwd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pwd.dao.EmployeeDAO;
import com.pwd.entities.Employee;



@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
private EmployeeDAO employeeDAO;

//By writing @autowired we are injecting EmployeeDAO class
public void setEmployeeDAO(EmployeeDAO employeeDAO)
{
	this.employeeDAO = employeeDAO;
}

	public void addEmployee(Employee employee) {
	
		employeeDAO.addEmployee(employee);
		System.out.println("***********");
	}


	public Employee fetchEmployeeById(int employeeId) {
		
		return employeeDAO.fetchEmployeeById(employeeId);
	}

	
	public void deleteEmployeeById(int employeeId) {
	
		employeeDAO.deleteEmployeeById(employeeId);
	}

	
	public void updateEmployeeEmailById(String newEmail, int employeeId) {
		
		employeeDAO.updateEmployeeEmailById(newEmail, employeeId);
	}


	public List<Employee> getAllEmployeeInfo() {
	
		return employeeDAO.getAllEmployeeInfo();
	}

}
